#include "library.h"
#include <iostream>
/*******************************
** Program:
** Author:
** Date: 
** Description:
** Input:
** Ouput:
*********************************/

int main(){
    Library l1;
    l1.fill_catalog();
    l1.menu();


    return 0;
}


